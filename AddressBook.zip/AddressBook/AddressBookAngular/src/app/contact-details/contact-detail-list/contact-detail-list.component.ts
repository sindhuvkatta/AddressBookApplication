import { Component, OnInit } from '@angular/core';
import { ContactDetailsService } from 'src/app/shared/contact-details.service';

@Component({
  selector: 'app-contact-detail-list',
  templateUrl: './contact-detail-list.component.html',
  styles:[]
})
export class ContactDetailListComponent implements OnInit {

  constructor(public service:ContactDetailsService) { }

  ngOnInit(): void {
    this.service.searchName="";
    this.service.searchTel="";
    this.service.errorMessage="";
    this.service.getContacts();
  }

  Search(): void {
    this.service.search();
  }

}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule  } from "@angular/common/http";


import { AppComponent } from './app.component';
import { ContactDetailsComponent } from './contact-details/contact-details.component';
import { ContactDetailListComponent } from './contact-details/contact-detail-list/contact-detail-list.component';
import { ContactDetailsService } from './shared/contact-details.service';

@NgModule({
  declarations: [
    AppComponent,
    ContactDetailsComponent,
    ContactDetailListComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [ContactDetailsService],
  bootstrap: [AppComponent]
})
export class AppModule { }

export class ContactDetail {
     ContactId:number; 
     FirstName:string;
     SurName:string;
     Tel:string;
     Cell:string;
     Email:string;
     CreatedDate:string;
     UpdatedDate:string;
     IsDeleted:boolean;
     IsActive:boolean;
}

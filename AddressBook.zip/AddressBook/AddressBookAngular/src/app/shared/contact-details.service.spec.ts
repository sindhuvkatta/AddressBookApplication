import { ContactDetailsService } from "./contact-details.service";
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe("ContactDetailsService",()=>{
let contactDetailsService: ContactDetailsService,
    httpTestingController:HttpTestingController;
beforeEach(()=>{
TestBed.configureTestingModule({
    imports:[
        HttpClientTestingModule
    ],
    providers:[
        ContactDetailsService
    ]
});
contactDetailsService=TestBed.get(ContactDetailsService);
httpTestingController = TestBed.get(HttpTestingController);
});

it("should retrieve all contacts",()=>{
    contactDetailsService.getContacts();   
    expect(contactDetailsService.list).toBeTrue;
});
it("should not return any record for a search",()=>{
    contactDetailsService.searchName="xxxxx";
    contactDetailsService.searchTel="ZZZZZ"
    contactDetailsService.search();
    expect(contactDetailsService.errorMessage=="Not Found").toBeTrue;
});
});
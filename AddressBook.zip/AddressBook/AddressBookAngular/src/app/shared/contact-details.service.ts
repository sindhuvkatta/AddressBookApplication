import { Injectable } from '@angular/core';
import { ContactDetail } from './contact-detail.model';
import { HttpClient, HttpErrorResponse  } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class ContactDetailsService {

 formData:ContactDetail;
 searchName:string;
 searchTel:string;
 errorMessage:string;
 loading:boolean;
 list: ContactDetail[];
 private rootUrl='https://localhost:44307/api/contacts';

  constructor(private http:HttpClient) { 
   
  }

  getContacts(){
    this.http.get(this.rootUrl)
    .toPromise()
    .then(res =>  {     
      this.errorMessage="";
      this.list=res as ContactDetail[];
      this.loading=false;
    }).catch((err: HttpErrorResponse) => {     
      this.list=[];
      this.errorMessage=err.error.title;
      console.error('An error occurred:', err.error);
      this.loading=false;
    });
  }  
  search(){
    this.loading=true;
    this.http.get(this.rootUrl+"/search?name="+this.searchName+"&telnumber="+this.searchTel)
    .toPromise()
    .then(res =>  {     
      this.errorMessage="";
      this.list=res as ContactDetail[];
      this.loading=false;
    }).catch((err: HttpErrorResponse) => {     
      this.list=[];
      this.errorMessage=err.error.title;
      console.error('An error occurred:', err.error);
      this.loading=false;
    });
  }
}

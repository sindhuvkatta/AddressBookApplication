﻿using AddressBook.Api.DBModels;
using AddressBook.Api.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace AddressBook.Tests
{
    public static class DbContextExtensions
    {
        public static void Seed(this AppDbContext dbContext)
        {
            dbContext.Contacts.Add(new Contact
            {
                ContactId = 10,
                FirstName = "Test One",
                Surname = "Tester",
                Tel = "+27 11 121 4350",
                Cell = "+27 11 121 4350",
                Email = "test@one.com",
                CreatedDate = DateTime.Now,
                IsActive = true
            });
            dbContext.Contacts.Add(new Contact
            {
                ContactId = 2,
                FirstName = "Test Two",
                Surname = "Tester",
                Tel = "+27 11 121 4351",
                Cell = "+27 11 121 4351",
                Email = "test@two.com",
                CreatedDate = DateTime.Now,
                IsActive = true
            });
            dbContext.Contacts.Add(new Contact
            {
                ContactId = 3,
                FirstName = "Test Three",
                Surname = "Tester",
                Tel = "+27 11 121 4352",
                Cell = "+27 11 121 4352",
                Email = "test@three.com",
                CreatedDate = DateTime.Now,
                IsActive = true
            });
            dbContext.Contacts.Add(new Contact
            {
                ContactId = 4,
                FirstName = "Test Four",
                Surname = "Tester",
                Tel = "+27 11 121 4353",
                Cell = "+27 11 121 4353",
                Email = "test@four.com",
                CreatedDate = DateTime.Now,
                IsActive = true
            });
            dbContext.SaveChanges();
        }
    }
}

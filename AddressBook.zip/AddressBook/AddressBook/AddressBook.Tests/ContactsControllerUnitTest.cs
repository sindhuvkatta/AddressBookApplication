﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AddressBook.Api.Controllers;
using AddressBook.Api.DBModels;
using AddressBook.Api.Models;
using Microsoft.AspNetCore.Mvc;
using NUnit.Framework;
using Xunit;

namespace AddressBook.Tests
{
    public class ContactsControllerUnitTest
    {       
        [Fact]
        public async Task TestGetContactsAsync()
        {
            // Arrange
           
            var dbContext = DbContextMocker.GetAppDbContext(nameof(TestGetContactsAsync));
            ContactRepository contactRepository = new ContactRepository(dbContext);
            var controller = new ContactsController(contactRepository);

            // Act
            var response = await controller.GetContacts() as ObjectResult;
            var value = response.Value as List<Contact>;

            dbContext.Dispose();

            // Assert
            Assert.False(value.Count==0);
        }
        [Fact]
        public async Task TestGetStockItemAsync()
        {
            // Arrange
            var dbContext = DbContextMocker.GetAppDbContext(nameof(TestGetContactsAsync));
            ContactRepository contactRepository = new ContactRepository(dbContext);
            var controller = new ContactsController(contactRepository);

            var name = "Test Three";
            var tel = "";

            // Act
            var response = await controller.Search(name, tel);
            var value = response.Value as Contact;

            dbContext.Dispose();

            // Assert
            Assert.True(value.FirstName==name);
        }

    }
}

﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace AddressBook.Api.Migrations
{
    public partial class InitailCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Contacts",
                columns: table => new
                {
                    ContactId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(nullable: false),
                    Surname = table.Column<string>(nullable: false),
                    Tel = table.Column<string>(nullable: true),
                    Cell = table.Column<string>(nullable: false),
                    Email = table.Column<string>(nullable: false),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    UpdatedDate = table.Column<DateTime>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false),
                    IsActive = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Contacts", x => x.ContactId);
                });

            migrationBuilder.InsertData(
                table: "Contacts",
                columns: new[] { "ContactId", "Cell", "CreatedDate", "Email", "FirstName", "IsActive", "IsDeleted", "Surname", "Tel", "UpdatedDate" },
                values: new object[,]
                {
                    { 1, "+27 610 524 131", new DateTime(2020, 5, 31, 12, 20, 55, 174, DateTimeKind.Local).AddTicks(3274), "adam@company.com", "Adam", true, false, "Len", "+27 610 524 131", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, "+27 611 524 132", new DateTime(2020, 5, 31, 12, 20, 55, 177, DateTimeKind.Local).AddTicks(398), "johan@company.com", "John", true, false, "Hastings", "+27 611 524 132", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 3, "+27 612 524 133", new DateTime(2020, 5, 31, 12, 20, 55, 177, DateTimeKind.Local).AddTicks(629), "coen@company.com", "Coen", true, false, "Red", "+27 612 524 133", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 4, "+27 613 524 134", new DateTime(2020, 5, 31, 12, 20, 55, 177, DateTimeKind.Local).AddTicks(670), "peter@company.com", "Peter", true, false, "lest", "+27 613 524 134", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Contacts");
        }
    }
}

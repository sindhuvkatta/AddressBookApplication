﻿using AddressBook.Api.DBModels;
using AddressBook.Api.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AddressBook.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactsController : ControllerBase
    {
        private readonly IContactRepository contactRepository;

        public ContactsController(IContactRepository contactRepository)
        {
            this.contactRepository = contactRepository;
        }

        [HttpGet("{search}")]
        public async Task<ActionResult<IEnumerable<Contact>>> Search(string name, string telnumber)
        {
            try
            {
                var result = await contactRepository.Search(name, telnumber);
                if (result.Any()) return Ok(result);
                return NotFound();
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieveing data from database");
            }
        }
        [HttpGet]
        public async Task<ActionResult> GetContacts()
        {
            try
            {
                return Ok(await contactRepository.GetContacts());
            }
            catch (Exception)
            {
                // we can create error log in to database table or file.. 
                return StatusCode(StatusCodes.Status500InternalServerError,
                    "Error retrieveing data from database");
            }

        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Contact>> GetContact(int id)
        {
            try
            {
                var result = await contactRepository.GetContact(id);
                if (result == null) return NotFound();
                return result;
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError,
                   "Error retrieveing data from database");
            }
        }

        [HttpPost]
        public async Task<ActionResult<Contact>> AddContact(Contact contact)
        {
            try
            {
                if (contact == null) return BadRequest();

                var cnt = await contactRepository.GetContactbyEmail(contact.Email);
                if (cnt != null)
                {
                    ModelState.AddModelError("email", "contact with this email already exist");
                    return BadRequest(ModelState);
                }
                var createdContact = await contactRepository.AddContact(contact);
                return CreatedAtAction(nameof(GetContact), new { id = createdContact.ContactId }, createdContact);
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError,
                 "Error creating the contact");
            }
        }
        [HttpPut("{id:int}")]
        public async Task<ActionResult<Contact>> UpdateContact(int id, Contact contact)
        {
            try
            {
                if (id != contact.ContactId)
                {
                    return BadRequest("Contact Id mismatch");
                }
                var contacToUpdate = await contactRepository.GetContact(id);
                if (contacToUpdate == null) return NotFound($"Contact with Id ={id} not found");

                return await contactRepository.UpdateContact(contact);

            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError,
               "Error updating the contact");
            }
        }
        [HttpDelete("{id:int}")]
        public async Task<ActionResult<Contact>> DeleteContact(int id)
        {
            try
            {
                var contacToDelete = await contactRepository.GetContact(id);
                if (contacToDelete == null) return NotFound($"Contact with Id ={id} not found");

                return await contactRepository.DeleteContact(id);
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError,
              "Error deleting the contact");
            }
        }
    }
}

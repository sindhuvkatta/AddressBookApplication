﻿using AddressBook.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AddressBook.Api.DBModels
{
    public interface IContactRepository
    {
        Task<IEnumerable<Contact>> Search(string name, string telNumber);
        Task<IEnumerable<Contact>> GetContacts();
        Task<Contact> GetContact(int contactId);
        Task<Contact> GetContactbyEmail(string email);
        Task<Contact> AddContact(Contact contact);
        Task<Contact> UpdateContact(Contact contact);
        Task<Contact> DeleteContact(int contactId);
    }
}

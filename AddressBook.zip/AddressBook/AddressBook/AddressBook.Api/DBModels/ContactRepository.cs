﻿using AddressBook.Api.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AddressBook.Api.DBModels
{
    public class ContactRepository : IContactRepository
    {
        private readonly AppDbContext appDbContext;

        public ContactRepository(AppDbContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }
        public async Task<Contact> AddContact(Contact contact)
        {
            var result = await appDbContext.Contacts.AddAsync(contact);
            await appDbContext.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Contact> DeleteContact(int contactId)
        {
            var contact = await appDbContext.Contacts.FirstOrDefaultAsync(o => o.ContactId == contactId);
            if (contact == null) return null;

            appDbContext.Contacts.Remove(contact);
            await appDbContext.SaveChangesAsync();
            return contact;
        }

        public async Task<Contact> GetContact(int contactId)
        {
            return await appDbContext.Contacts.FirstOrDefaultAsync(o => o.ContactId == contactId);
        }

        public async Task<Contact> GetContactbyEmail(string email)
        {
            return await appDbContext.Contacts.FirstOrDefaultAsync(o => o.Email == email);
        }

        public async Task<IEnumerable<Contact>> GetContacts()
        {
            return await appDbContext.Contacts.ToListAsync();
        }

        public async Task<IEnumerable<Contact>> Search(string name, string telNumber)
        {
            IQueryable<Contact> query = appDbContext.Contacts;
            if (!string.IsNullOrEmpty(name))
            {
                query = query.Where(o => o.FirstName.Contains(name) || o.Surname.Contains(name));

            }
            if(!string.IsNullOrEmpty(telNumber))
            {
                query = query.Where(o => o.Tel.Contains(telNumber));

            }
            return await query.ToListAsync();
            
        }

        public async Task<Contact> UpdateContact(Contact contact)
        {
            var result = await appDbContext.Contacts.FirstOrDefaultAsync(o => o.ContactId == contact.ContactId);
            if (result == null) return null;

            result.FirstName = contact.FirstName;
            result.Surname = contact.Surname;
            result.Tel = contact.Tel;
            result.Cell = contact.Cell;
            result.Email = contact.Email;
            result.UpdatedDate = DateTime.Now;
            result.IsActive = contact.IsActive;
            await appDbContext.SaveChangesAsync();
            return result;

        }
    }
}

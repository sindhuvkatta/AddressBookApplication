﻿using AddressBook.Api.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AddressBook.Api.DBModels
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
        {
        }
        public DbSet<Contact> Contacts { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //Send Contacts Information
            modelBuilder.Entity<Contact>().HasData(
               new Contact
               {
                   ContactId = 1,
                   FirstName = "Adam",
                   Surname = "Len",
                   Tel = "+27 610 524 131",
                   Cell = "+27 610 524 131",
                   Email = "adam@company.com",
                   CreatedDate = DateTime.Now,
                   IsActive = true
               });
            modelBuilder.Entity<Contact>().HasData(
                new Contact
                {
                    ContactId = 2,
                    FirstName = "John",
                    Surname = "Hastings",
                    Tel = "+27 611 524 132",
                    Cell = "+27 611 524 132",
                    Email = "johan@company.com",
                    CreatedDate = DateTime.Now,
                    IsActive = true
                });
            modelBuilder.Entity<Contact>().HasData(
              new Contact
              {
                  ContactId = 3,
                  FirstName = "Coen",
                  Surname = "Red",
                  Tel = "+27 612 524 133",
                  Cell = "+27 612 524 133",
                  Email = "coen@company.com",
                  CreatedDate = DateTime.Now,
                  IsActive = true
              });
            modelBuilder.Entity<Contact>().HasData(
             new Contact
             {
                 ContactId = 4,
                 FirstName = "Peter",
                 Surname = "lest",
                 Tel = "+27 613 524 134",
                 Cell = "+27 613 524 134",
                 Email = "peter@company.com",
                 CreatedDate = DateTime.Now,
                 IsActive = true
             });
        }

    }
}
